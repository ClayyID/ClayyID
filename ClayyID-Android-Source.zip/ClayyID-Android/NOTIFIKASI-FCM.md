# Mengaktifkan notifikasi push ClayyID (FCM)

Fitur notifikasi di starter project saat ini baru meminta izin Android dan membuat channel. Agar notifikasi bisa diterima saat aplikasi tertutup:

1. Buat project di Firebase Console.
2. Tambahkan Android app dengan package ID `id.clayyid.app`.
3. Unduh `google-services.json` dan letakkan di folder `app/`.
4. Tambahkan plugin Google Services dan dependency Firebase Cloud Messaging ke Gradle.
5. Implementasikan `FirebaseMessagingService` untuk menerima token dan pesan.
6. Simpan token perangkat pada backend website dan kirim pesan FCM dari backend menggunakan Firebase Admin SDK.
7. Uji notifikasi saat aplikasi foreground, background, dan ditutup.

Jangan pernah menaruh kredensial Firebase Admin/service-account di aplikasi Android atau frontend website.
