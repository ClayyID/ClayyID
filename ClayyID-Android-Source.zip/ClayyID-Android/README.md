# ClayyID Android

Android WebView wrapper for https://nocode-builder-91.emergent.host/.

## Included
- App name: ClayyID
- Launcher icon based on the supplied game-controller logo
- White splash screen using the supplied logo
- Fullscreen immersive WebView
- JavaScript, DOM storage and cookies enabled for the hosted web app
- Android notification permission request and notification channel
- Back button navigates within the website

## Build APK
1. Install Android Studio (current stable) on a computer.
2. Open this folder (`ClayyID-Android`) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).
6. Transfer the APK to the Android phone and install it. Android may ask permission to install unknown apps.

## Important: push notifications
This starter project requests notification permission and creates the Android notification channel, but it does **not** yet receive remote push notifications. Remote notifications require Firebase Cloud Messaging (FCM), a Firebase Android app registered with package ID `id.clayyid.app`, the matching `google-services.json`, an FCM service in the Android app, and a server/backend on the website that sends FCM messages. Merely granting notification permission does not make a website send notifications. The website's current notification capability has not been verified.

## Before public release
- Confirm the website owner permits embedding in a WebView and that login, checkout/payment, file upload, external links and any OAuth flows work correctly.
- Add proper handling for file chooser/camera if the website needs uploads.
- Add FCM end-to-end and test on a real Android device.
- Create a signed release APK using a private keystore. Do not share the keystore or its passwords.
- Add a privacy policy and verify the site's data handling before distribution.

Package ID: `id.clayyid.app`
Version: `1.0.0` (versionCode 1)
